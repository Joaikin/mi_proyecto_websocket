﻿const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });
const clients = [];

wss.on('connection', function connection(ws) {
    clients.push(ws);
    broadcastUserList(); // Enviar la lista de usuarios al nuevo cliente

    ws.on('message', function incoming(message) {
        try {
            const data = JSON.parse(message);
            if (data.type === 'getUserList') {
                broadcastUserList(ws); // Enviar la lista de usuarios solo al solicitante
            } else {
                broadcast({ username: data.username, text: data.text });
            }
        } catch (error) {
            console.error('Error al analizar el mensaje:', error);
        }
    });

    ws.on('close', () => {
        clients.splice(clients.indexOf(ws), 1);
        broadcastUserList();
    });
});

function broadcast(message) {
    const messageString = JSON.stringify(message);
    clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(messageString);
        }
    });
}

function broadcastUserList(specificClient = null) {
    const userList = clients.map(client => ({ username: client.username })); // Solo enviar nombres de usuario
    const message = JSON.stringify({ type: 'userList', users: userList });
    if (specificClient) {
        specificClient.send(message); // Enviar solo al solicitante
    } else {
        broadcast(message); // Enviar a todos
    }
}
